Sample configuration files for:
```
SystemD: nesteggd.service
Upstart: nesteggd.conf
OpenRC:  nesteggd.openrc
         nesteggd.openrcconf
CentOS:  nesteggd.init
macOS:    org.nestegg.nesteggd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
