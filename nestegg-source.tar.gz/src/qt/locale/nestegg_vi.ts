<TS language="vi" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Ấn chuột phải để sửa địa chỉ hoặc tên</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Tạo địa chỉ mới </translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>Mới</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>Sao chép</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Xóa các địa chỉ được chọn khỏi danh sách</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>Xóa</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Xuất dữ liệu của tab hiện tại sang file</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>Xuất</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>Đóng</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Chọn địa chỉ để gửi coin đi</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Chọn địa chỉ để nhận coin về</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>Chọn</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Địa chỉ nhận</translation>
    </message>
    <message>
        <source>Receiving addresses</source>
        <translation>Địa chỉ gửi </translation>
    </message>
    <message>
        <source>These are your NestEGG addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Đây là địa chỉ ví NestEGG của bạn để gửi đi. Luôn luôn kiểm tra số lượng và địa chỉ ví nhận trước khi gửi.</translation>
    </message>
    <message>
        <source>These are your NestEGG addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Đây là địa chỉ ví NestEGG của bạn để nhận. Bạn nên sử dụng địa chỉ ví nhận mới cho mỗi giao dịch</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Unlock wallet</source>
        <translation>Mở khóa ví</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>Bip38ToolDialog</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Unlock wallet</source>
        <translation>Mở khóa ví</translation>
    </message>
    </context>
<context>
    <name>BlockExplorer</name>
    </context>
<context>
    <name>ClientModel</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>GovernancePage</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>MasternodeList</name>
    </context>
<context>
    <name>MultiSendDialog</name>
    </context>
<context>
    <name>MultisigDialog</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>PrivacyDialog</name>
    </context>
<context>
    <name>ProposalFrame</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>Xuất</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Xuất dữ liệu của tab hiện tại sang file</translation>
    </message>
    </context>
<context>
    <name>ZPivControlDialog</name>
    </context>
<context>
    <name>nestegg-core</name>
    </context>
</TS>